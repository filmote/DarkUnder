#ifndef ITEM_H
#define ITEM_H

#include <Arduboy2.h>
#include "Enums.h"

struct Item {

  bool enabled;
  ItemType itemType;
  int x;
  int y;

};

#endif
