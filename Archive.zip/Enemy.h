#ifndef ENEMY_H
#define ENEMY_H

#include <Arduboy2.h>
#include "Level.h"
#include "Enums.h"

struct Enemy {

  bool enabled;
  EnemyType enemyType;
  int x;
  int y;

  void moveEnemy(Level *level, Button playerMove) {

    if (!canMoveEnemy(level, playerMove)) {
      
      while (true) {

        if (canMoveEnemy(level, (Button)random(0, 4))) { break; }

      }

    }

  }

  boolean canMoveEnemy(Level *level, Button playerMove) {

    if (playerMove == Button::Up && moveLegal(level, x, y - 1)) {
      --y;
    } 
    else if (playerMove == Button::Down && moveLegal(level, x, y + 1)) {
      ++y;
    } 
    else if (playerMove == Button::Right && moveLegal(level, x + 1, y)) {
      ++x;
    } 
    else if (playerMove == Button::Left && moveLegal(level, x - 1, y)) {
      --x;
    } 
    else {
    
      return false;

    }

    return true;

  }
    


  boolean moveLegal(Level *level, int x, int y) {
    
    if (level->getMapElement(x, y) == MapElement::Floor) {
      return true;
    } 
    else {
      return false;
    }
    
  }  

};

#endif
